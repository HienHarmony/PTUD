from django.urls import path
from . import views

urlpatterns = [
    path('cv/<str:username>/', views.view_cv, name='view_cv'),  # Đã thêm định danh 'view_cv'
    path('generate_fake_data/', views.generate_fake_data, name='generate_fake_data'),
    # Thêm các đường dẫn khác nếu cần
]
