from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import UserProfile
from faker import Faker

def generate_fake_data(request):
    fake = Faker()

    for _ in range(10):
        user = User.objects.create_user(username=fake.user_name(), password=fake.password())
        profile = UserProfile.objects.create(
            user=user,
            name=fake.name(),
            role=fake.job(),
            email=fake.email(),
            phone_number=fake.phone_number(),
            education=fake.text(),
            experience=fake.text(),
            skills=fake.text()
        )

    return HttpResponse("Successfully populated the database with fake data")


def view_cv(request, username):
    try:
        user_profile = UserProfile.objects.get(user__username=username)
    except UserProfile.DoesNotExist:
        # Nếu không tìm thấy, tạo dữ liệu giả mạo
        user_profile = generate_fake_data()

    return render(request, 'cv.html', {'user_profile': user_profile})
