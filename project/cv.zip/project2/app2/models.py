from django.contrib.auth.models import User
from django.db import models

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="Người dùng")
    name = models.CharField(max_length=100, verbose_name="Tên")
    role = models.CharField(max_length=100, verbose_name="Vai trò")
    email = models.EmailField(verbose_name="Email")
    phone_number = models.CharField(max_length=15, verbose_name="Số điện thoại")
    education = models.TextField(verbose_name="Học vấn")
    experience = models.TextField(verbose_name="Kinh nghiệm làm việc")
    skills = models.TextField(null=True, blank=True, verbose_name="Kỹ năng")

    def __str__(self):
        return self.name
