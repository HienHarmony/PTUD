from django.shortcuts import render

from django.http import HttpResponse
import datetime
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from .models import Task
import json
# app/views.py
from django.shortcuts import render
from .models import Task
def get_home(request):
    return render(request, 'home.html')

def current_datetime(request):
    now = datetime.datetime.now()
    html = "<html><body>It is now %s.</body></html>" % now
    return HttpResponse(html)


def task_list(request):
    tasks = Task.objects.all()
    return render(request, 'home.html', {'tasks': tasks})

def add_task(request):
    print('Incoming request:', request)
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            title = data.get('title')
            if title:
                task = Task.objects.create(title=title)
                return JsonResponse({'success': True, 'task_id': task.id})
        except json.JSONDecodeError as e:
            return JsonResponse({'success': False, 'error': 'Invalid JSON format'})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

def toggle_task(request):
    if request.method == 'POST':
        data = request.json()
        task_id = data.get('task_id')
        if task_id:
            task = get_object_or_404(Task, id=task_id)
            task.completed = not task.completed
            task.save()
            return JsonResponse({'success': True})
    return JsonResponse({'success': False})
def delete_task(request, task_id):
    print(task_id)
    if request.method == 'POST':
        task = get_object_or_404(Task, id=task_id)
        task.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


def complete_task(request, task_id):
    if request.method == 'POST':
        task = get_object_or_404(Task, id=task_id)
        task.completed = not task.completed
        task.save()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})