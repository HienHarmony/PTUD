from django.urls import path ,include 
from . import views 


urlpatterns = [
    path('current_datetime/', views.current_datetime),  
    path('home/',views.get_home),
    path('task/',views.task_list),
    path('add-task/', views.add_task, name='add_task'),
    path('toggle-task/', views.toggle_task, name='toggle_task'),
    path('delete-task/<int:task_id>/', views.delete_task, name='delete_task'),
    path('complete-task/<int:task_id>/', views.complete_task, name='complete_task'),


]

