// function addTask() {
//     var taskInput = document.getElementById("new-task");
//     var taskText = taskInput.value.trim();

//     if (taskText !== "") {
//         fetch('/App/add-task/', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json',
//                 'X-CSRFToken': getCookie('csrftoken'),
//             },
//             body: JSON.stringify({ title: taskText }),
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             if (data.success) {
//                 var taskList = document.getElementById("task-list");
//                 var newTask = document.createElement("li");
//                 newTask.textContent = taskText;
//                 newTask.onclick = function() {
//                     toggleTask(this, data.task_id);
//                 };
//                 taskList.appendChild(newTask);
//                 taskInput.value = "";
//             } else {
//                 console.error('Error:', data.error);
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// }
// // Hàm để lấy giá trị csrf token từ cookie
// function getCookie(name) {
//     var value = "; " + document.cookie;
//     var parts = value.split("; " + name + "=");
//     if (parts.length === 2) return parts.pop().split(";").shift();
// }
// function deleteTask(taskId) {
//     fetch(`/App/delete-task/${taskId}/`, {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//             'X-CSRFToken': getCookie('csrftoken'),
//         },
//     })
//     .then(response => response.json())
//     .then(data => {
//         if (data.success) {
//             document.getElementById(taskId).remove();
//         }
//     })
//     .catch(error => console.error('Error:', error));
// }
// function completeTask(taskId) {
//     fetch(`/App/complete-task/${taskId}/`, {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//             'X-CSRFToken': getCookie('csrftoken'),
//         },
//     })
//     .then(response => response.json())
//     .then(data => {
//         if (data.success) {
//             // Add your code to visually indicate task completion, for example, by adding a class
//             var taskElement = document.getElementById(taskId);
//             taskElement.classList.toggle("completed");
//         }
//     })
//     .catch(error => console.error('Error:', error));
// }
// bai1.js
document.addEventListener('DOMContentLoaded', function () {
    // Khi trang được tải, tải danh sách công việc từ server
    loadTasks();
});

function loadTasks() {
    fetch('/App/task-list/')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                var taskList = document.getElementById("task-list");
                taskList.innerHTML = ''; // Xóa nội dung cũ của danh sách

                data.tasks.forEach(task => {
                    var newTask = document.createElement("li");
                    newTask.id = task.id;
                    newTask.textContent = task.title;
                    newTask.className = task.completed ? 'completed' : '';
                    newTask.onclick = function () {
                        toggleTask(this, task.id);
                    };

                    var taskButtons = document.createElement("div");
                    taskButtons.className = "task-buttons";

                    var deleteButton = document.createElement("button");
                    deleteButton.textContent = "Xóa";
                    deleteButton.onclick = function () {
                        deleteTask(task.id);
                    };

                    var completeCheckbox = document.createElement("input");
                    completeCheckbox.type = "checkbox";
                    completeCheckbox.checked = task.completed;
                    completeCheckbox.onchange = function () {
                        completeTask(task.id, this.checked);
                    };

                    taskButtons.appendChild(deleteButton);
                    taskButtons.appendChild(completeCheckbox);

                    newTask.appendChild(taskButtons);

                    taskList.appendChild(newTask);
                });
            } else {
                console.error('Error:', data.error);
            }
        })
        .catch(error => console.error('Error:', error));
}

function addTask() {
    var taskInput = document.getElementById("new-task");
    var taskText = taskInput.value.trim();

    if (taskText !== "") {
        fetch('/App/add-task/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken'),
            },
            body: JSON.stringify({ title: taskText }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Thêm công việc mới vào danh sách và hiển thị ngay lập tức
                var taskList = document.getElementById("task-list");
                var newTask = document.createElement("li");
                newTask.id = data.task_id;
                newTask.textContent = taskText;
                newTask.onclick = function () {
                    toggleTask(this, data.task_id);
                };

                var taskButtons = document.createElement("div");
                taskButtons.className = "task-buttons";

                var deleteButton = document.createElement("button");
                deleteButton.textContent = "Xóa";
                deleteButton.onclick = function () {
                    deleteTask(data.task_id);
                };

                var completeCheckbox = document.createElement("input");
                completeCheckbox.type = "checkbox";
                completeCheckbox.onchange = function () {
                    completeTask(data.task_id, this.checked);
                };

                taskButtons.appendChild(deleteButton);
                taskButtons.appendChild(completeCheckbox);

                newTask.appendChild(taskButtons);

                taskList.appendChild(newTask);

                taskInput.value = "";
            } else {
                console.error('Error:', data.error);
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

function deleteTask(taskId) {
    fetch(`/App/delete-task/${taskId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken'),
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Xóa công việc khỏi danh sách và hiển thị ngay lập tức
            var taskList = document.getElementById("task-list");
            var taskToRemove = document.getElementById(taskId);
            taskList.removeChild(taskToRemove);
        }
    })
    .catch(error => console.error('Error:', error));
}

function completeTask(taskId, completed) {
    fetch(`/App/complete-task/${taskId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken'),
        },
        body: JSON.stringify({ completed: completed }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Cập nhật trạng thái của công việc và hiển thị ngay lập tức
            var taskElement = document.getElementById(taskId);
            taskElement.classList.toggle("completed", completed);
        }
    })
    .catch(error => console.error('Error:', error));
}

// Hàm để lấy giá trị csrf token từ cookie
function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length === 2) return parts.pop().split(";").shift();
}
